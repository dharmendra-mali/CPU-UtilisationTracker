import { Injectable } from '@angular/core';
import * as io from 'socket.io-client'
import { observable, Subscriber, Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ScoketService {
  socket: any
  constructor() {
    this.socket = io('http://localhost:3000');
  }

  currentDataListen(Eventname: string) {
    console.log('in listen ')
    return new Observable((subscriber) => {
      this.socket.on(Eventname,
        (data) => {
          subscriber.next(data);
        });
    })

  }
  previousDataListen(Eventname: string) {
    // console.log('inside service')
    return new Observable((subscriber) => {
      this.socket.on(Eventname,
        (data) => {
          subscriber.next(data);
        });
    })

  }
  fatchPreviousData(processId){
    this.socket.emit('visited', processId);
  }

  sendProcessId(processId){
   // console.log('data emit from angular input')
    this.socket.emit('processId', processId);
  }

  stopListen(){
    console.log('stop')
    this.socket.emit('stop',undefined)
  }
}
