export class Process {
    constructor(public loads?: string,
        public time?: string
    ) { }
}