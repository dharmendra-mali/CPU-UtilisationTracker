import { Component, OnInit, Input } from '@angular/core';

import { Chart } from 'chart.js'
import { ScoketService } from '../scoket.service';
import { Process } from './process.model';
@Component({
  selector: 'app-livechart',
  templateUrl: './livechart.component.html',
  styleUrls: ['./livechart.component.css']
})
export class LivechartComponent implements OnInit {
  @Input() processExists
  lineChart;
  //process:Process[]
  chartData = []
  label = [];
  constructor(private scoketService: ScoketService) { }

  ngOnInit(): void {
    
    if (this.processExists) {

      this.scoketService.previousDataListen('preservedata').subscribe((processData: any[]) => {
        processData.forEach((processDataItem) => {
          this.chartData.push(processDataItem['loads'])
          this.label.push(processDataItem['time'])
          // this.process.push({loads:d['loads'],time:d['time']})

        })
        this.lineChart.update();
      })

    }
    this.scoketService.currentDataListen('dataupdate').subscribe((processDataItem) => {
      //console.log(data)
      this.chartData.push(processDataItem['loads']);
      this.label.push(processDataItem['time']);
      //this.process.push({loads:data['loads'],time:data['time']})
      this.lineChart.update();
    })


    this.lineChart = new Chart('lineChart', {
      type: 'line',
      data: {
        labels: this.label,
        datasets: [{
          label: 'cpu consumption by process',
          data: this.chartData,
          fill: false,
          lineTension: 0.2,
          borderColor: "red",
          borderWidth: 1
        }]
      },
      options: {
        title: {
          text: "Line Chart",
          display: true
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  }

}
