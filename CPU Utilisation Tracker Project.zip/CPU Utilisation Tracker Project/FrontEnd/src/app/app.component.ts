import { Component } from '@angular/core';
import { Chart } from 'chart.js'

import { EventEmitter } from 'events';
import { ScoketService } from './scoket.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  processId;
  processExists = undefined
  constructor(private scoketservice: ScoketService) { }

  ngOnInit() {

    if (localStorage.getItem('id') != null) {
     let id=localStorage.getItem('id');
      this.processExists = true
      this.scoketservice.fatchPreviousData(id)
     
    }



  }
  submit() {
    this.scoketservice.sendProcessId(this.processId)
    this.processExists = true;
    localStorage.setItem('id', this.processId);

  }

  stop() {
    localStorage.clear()
    this.scoketservice.stopListen()
  }

}