import { TestBed } from '@angular/core/testing';

import { ScoketService } from './scoket.service';

describe('ScoketService', () => {
  let service: ScoketService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ScoketService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
