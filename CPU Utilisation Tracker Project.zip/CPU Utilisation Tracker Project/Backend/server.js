const app = require('express')();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const cpu = require('windows-cpu');
const connectDB = require('./config/db')
const Process = require('./model/Process')

connectDB()

app.get('/', (req, res) => {
    res.send('<h1>Hello World</h1>')
});

http.listen(3000, () => {
    console.log('server is listeing');
});

io.on('connection', (socket) => {
    // console.log(`new connection id: ${socket.id}`);

    socket.on('processId', (id) => {
        sendCurrentData(socket, id);
    })
    socket.on('visited', (id) => {
        sendPreserveData(socket, id)
    })
    socket.on('stop', (id) => {
        // socket.removeListener('dataupdate',(name)=>{

        // })
        sendCurrentData(socket, id);
    })


});
async function stop() {
    try {
        await Process.deleteMany({});

    } catch (error) {

    }
}

async function sendCurrentData(socket, id) {

    let loads;
    let time;
    let process;
    if (id == undefined) {
      stop();
        clearTimeout(timeOutObj);
        return;
    } else {
        try {

            await cpu.findLoad(id).then(({ load, found }) => { loads = load });
            time = new Date();
            time = time.getHours() + ':' + time.getMinutes() + ':' + time.getSeconds();

        } catch (e) {
            loads = 0;
            time = new Date();
            time = time.getHours() + ':' + time.getMinutes() + ':' + time.getSeconds();
        }
        try {
            process = await Process.create({ loads: loads, time: time });
        } catch (error) {
            console.log('mongoose erro' + error)
        }

        socket.emit('dataupdate', { loads: loads, time: time });
        timeOutObj = setTimeout(() => {
            sendCurrentData(socket, id);
        }, 10000)
    }




}

async function sendPreserveData(socket, id) {

    let process = await Process.find();
    socket.emit('preservedata', process);

    sendCurrentData(socket, id);

}
