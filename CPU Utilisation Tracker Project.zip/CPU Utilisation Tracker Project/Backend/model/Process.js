const mongoose = require('mongoose');


const ProcessSchema =  mongoose.Schema({
  loads: {
    type: String,
   
  },
  time: {
    type: String,
   
   }
 
});



const Process = mongoose.model('Process', ProcessSchema)

module.exports = Process